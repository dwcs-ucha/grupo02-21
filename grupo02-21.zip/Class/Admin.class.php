<?php

/**
 * Description of Admin
 *
 * @author Oscar González Martínez
 * Clase Admin - Proyecto DAWT-DWCS
 */
class Admin extends Persona{
    //put your code here
        
    
}
