<?php
/* 
 * Calculadora avazada
 * Punto de entrada a las vistas
 * @author Miguel A García Fustes
 * @date 25 de Noviembre de 2021
 * @version 1.0.0
 */
?>
 <!DOCTYPE html>
 <html lang="es">
 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Calculadora avanzada</title>
 </head>
 <body>
    <?php include './vistas/datos.php'; ?> 
 </body>
 </html>