<?php
/* 
 * Calculadora avanzada
 * Vista petición de datos
 * @author Miguel A García Fustes
 * @date 25 de Noviembre de 2021
 * @version 1.0.0
 */
?>
<div class="container">
    <div class="row-fluid">
        <div class="col">Hola Mundo</div>
    </div>
</div>