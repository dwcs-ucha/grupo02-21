<?php
/* 
 * Calculadora avazada
 * Vista para pedir los equipos disponibles
 * @author Miguel A García Fustes
 * @date  de  de 2021
 * @version 1.0.0
 */